'use client';

import { useState, useEffect, useRef } from 'react';
import { malaysianDrinks } from '@/data/malaysianFoodData';

export default function Home() {
  const [currentPage, setCurrentPage] = useState('home');
  const [menuOpen, setMenuOpen] = useState(false);
  const [newsPopupOpen, setNewsPopupOpen] = useState(false);
  
  // Chat state
  const [chatMessages, setChatMessages] = useState([
    {
      role: 'bot',
      content: "Hi! I'm your personal nutrition assistant powered by Malaysian food data. I can help you with eating habits, health concerns, meal planning, and more. What would you like to know?"
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Drink tracker state
  const [selectedDrinks, setSelectedDrinks] = useState<{
    breakfast?: string;
    lunch?: string;
    dinner?: string;
  }>({});
  const [drinkAnalysis, setDrinkAnalysis] = useState<any>(null);
  const [analysisLoading, setAnalysisLoading] = useState(false);

  // Auto-show news popup
  useEffect(() => {
    const timer = setTimeout(() => {
      if (currentPage === 'home') {
        setNewsPopupOpen(true);
      }
    }, 5000);

    return () => clearTimeout(timer);
  }, [currentPage]);

  // Auto-scroll chat
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatMessages]);

  // Send chat message
  const sendChatMessage = async () => {
    if (!chatInput.trim()) return;

    const userMessage = chatInput;
    setChatInput('');
    
    // Add user message
    setChatMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setChatLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage })
      });

      const data = await response.json();
      
      // Add bot response
      setChatMessages(prev => [...prev, { 
        role: 'bot', 
        content: data.response 
      }]);
    } catch (error) {
      console.error('Chat error:', error);
      setChatMessages(prev => [...prev, { 
        role: 'bot', 
        content: 'Sorry, I encountered an error. Please try again.' 
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  // Quick question
  const askQuickQuestion = (question: string) => {
    setChatInput(question);
    setTimeout(() => sendChatMessage(), 100);
  };

  // Select drink and analyze
  const selectDrink = async (meal: 'breakfast' | 'lunch' | 'dinner', drinkId: string) => {
    const newSelection = { ...selectedDrinks, [meal]: drinkId };
    setSelectedDrinks(newSelection);

    // Only analyze if at least one drink is selected
    if (Object.values(newSelection).some(id => id)) {
      setAnalysisLoading(true);
      
      try {
        const response = await fetch('/api/analyze-drink', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newSelection)
        });

        const data = await response.json();
        setDrinkAnalysis(data.data);
      } catch (error) {
        console.error('Analysis error:', error);
      } finally {
        setAnalysisLoading(false);
      }
    }
  };

  return (
    <div className="phone-container">
      <div className="notch" />
      <div className="screen">
        
        {/* Home Page */}
        <div className={`page ${currentPage === 'home' ? 'active' : ''}`}>
          <div className="header">
            <div>
              <div className="greeting">Hello, Sarah! 👋</div>
              <div className="subtext">🇲🇾 Made for Malaysia</div>
            </div>
            <button className="menu-btn" onClick={() => setMenuOpen(true)}>☰</button>
          </div>

          <div className="avatar-container">
            <div className="avatar-display">
              <div className="avatar">😊</div>
              <div className="avatar-info">
                <h3>Healthy Hero</h3>
                <span className="avatar-status">Feeling Great</span>
              </div>
            </div>
            <div className="streak-info">
              <div className="streak-card">
                <div className="streak-number">🔥 12</div>
                <div className="streak-label">Day Streak</div>
              </div>
              <div className="streak-card" style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }}>
                <div className="streak-number">⭐ 248</div>
                <div className="streak-label">Total Points</div>
              </div>
            </div>
          </div>

          <div className="quick-actions">
            <div className="section-title">Main Features</div>
            <div className="action-grid">
              <div className="action-card" onClick={() => setCurrentPage('flavor-match')}>
                <div className="action-icon">🎯</div>
                <div className="action-title">Flavor Match</div>
                <div className="action-desc">Malaysian cuisines</div>
              </div>
              <div className="action-card" onClick={() => setCurrentPage('nearby-healthy')}>
                <div className="action-icon" style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }}>📍</div>
                <div className="action-title">Nearby Healthy</div>
                <div className="action-desc">GPS food finder</div>
              </div>
              <div className="action-card" onClick={() => setCurrentPage('family')}>
                <div className="action-icon" style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)' }}>👨‍👩‍👧</div>
                <div className="action-title">Family Health</div>
                <div className="action-desc">Track loved ones</div>
              </div>
              <div className="action-card" onClick={() => setCurrentPage('drink-tracker')}>
                <div className="action-icon" style={{ background: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)' }}>🥤</div>
                <div className="action-title">Drink Tracker</div>
                <div className="action-desc">Monitor sugar intake</div>
              </div>
            </div>
          </div>

          <div className="camera-button" onClick={() => setCurrentPage('camera')}>📷</div>
        </div>

        {/* Chatbot Page */}
        <div className={`page ${currentPage === 'chatbot' ? 'active' : ''}`}>
          <div className="header">
            <div>
              <div className="greeting">AI Health Assistant 💬</div>
              <div className="subtext">Ask anything about nutrition</div>
            </div>
            <button className="menu-btn" onClick={() => setMenuOpen(true)}>☰</button>
          </div>

          <div className="chat-container" ref={chatContainerRef}>
            {chatMessages.map((msg, idx) => (
              <div key={idx} className={`chat-message ${msg.role}`}>
                {msg.role === 'bot' && <div className="chat-avatar">🤖</div>}
                <div 
                  className={`chat-bubble ${msg.role}`}
                  dangerouslySetInnerHTML={{ __html: msg.content }}
                />
              </div>
            ))}
            {chatLoading && (
              <div className="chat-message bot">
                <div className="chat-avatar">🤖</div>
                <div className="chat-bubble bot">Thinking...</div>
              </div>
            )}

            <div className="quick-questions">
              <div className="quick-question" onClick={() => askQuickQuestion('What should I eat for dinner?')}>
                Dinner ideas?
              </div>
              <div className="quick-question" onClick={() => askQuickQuestion('Is nasi lemak healthy?')}>
                Nasi lemak healthy?
              </div>
              <div className="quick-question" onClick={() => askQuickQuestion('Low sugar drinks')}>
                Low sugar drinks
              </div>
              <div className="quick-question" onClick={() => askQuickQuestion('Weight loss tips')}>
                Weight loss tips
              </div>
            </div>
          </div>

          <div className="chat-input-container">
            <input
              type="text"
              className="chat-input"
              placeholder="Ask about nutrition, meals, health..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendChatMessage()}
            />
            <button className="chat-send-btn" onClick={sendChatMessage}>➤</button>
          </div>

          <div className="nav-bar">
            <div className="nav-item" onClick={() => setCurrentPage('home')}>
              <div className="nav-icon">🏠</div>
              <div className="nav-label">Home</div>
            </div>
            <div className="nav-item active">
              <div className="nav-icon">💬</div>
              <div className="nav-label">Chat</div>
            </div>
            <div className="nav-item" onClick={() => setCurrentPage('camera')}>
              <div className="nav-icon">📸</div>
              <div className="nav-label">Scan</div>
            </div>
            <div className="nav-item" onClick={() => setMenuOpen(true)}>
              <div className="nav-icon">☰</div>
              <div className="nav-label">Menu</div>
            </div>
          </div>
        </div>

        {/* Drink Tracker Page */}
        <div className={`page ${currentPage === 'drink-tracker' ? 'active' : ''}`}>
          <div className="header">
            <div>
              <div className="greeting">Drink Tracker 🥤</div>
              <div className="subtext">Monitor sugar & health risks</div>
            </div>
            <button className="menu-btn" onClick={() => setMenuOpen(true)}>☰</button>
          </div>

          <div className="content-section">
            <div className="feature-card fade-in">
              <div className="feature-header">
                <div className="feature-icon" style={{ background: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)' }}>🥤</div>
                <div className="feature-title">Today's Drinks</div>
              </div>

              <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '16px' }}>
                Select what you drank with each meal:
              </p>

              {/* Breakfast */}
              <div style={{ marginBottom: '20px' }}>
                <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937', marginBottom: '10px' }}>
                  🌅 Breakfast
                </div>
                {malaysianDrinks.slice(0, 3).map(drink => (
                  <div
                    key={drink.id}
                    className={`drink-card ${selectedDrinks.breakfast === drink.id ? 'selected' : ''}`}
                    onClick={() => selectDrink('breakfast', drink.id)}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontWeight: 600, color: '#1f2937' }}>{drink.name}</div>
                        <div style={{ fontSize: '12px', color: '#6b7280' }}>
                          {drink.sugarGrams}g sugar • {drink.calories} kcal
                        </div>
                      </div>
                      <div style={{ fontSize: '24px' }}>{drink.emoji}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Lunch */}
              <div style={{ marginBottom: '20px' }}>
                <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937', marginBottom: '10px' }}>
                  ☀️ Lunch
                </div>
                {malaysianDrinks.slice(2, 5).map(drink => (
                  <div
                    key={drink.id}
                    className={`drink-card ${selectedDrinks.lunch === drink.id ? 'selected' : ''}`}
                    onClick={() => selectDrink('lunch', drink.id)}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontWeight: 600, color: '#1f2937' }}>{drink.name}</div>
                        <div style={{ fontSize: '12px', color: '#6b7280' }}>
                          {drink.sugarGrams}g sugar • {drink.calories} kcal
                        </div>
                      </div>
                      <div style={{ fontSize: '24px' }}>{drink.emoji}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Dinner */}
              <div>
                <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937', marginBottom: '10px' }}>
                  🌙 Dinner
                </div>
                {malaysianDrinks.slice(4, 7).map(drink => (
                  <div
                    key={drink.id}
                    className={`drink-card ${selectedDrinks.dinner === drink.id ? 'selected' : ''}`}
                    onClick={() => selectDrink('dinner', drink.id)}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontWeight: 600, color: '#1f2937' }}>{drink.name}</div>
                        <div style={{ fontSize: '12px', color: '#6b7280' }}>
                          {drink.sugarGrams}g sugar • {drink.calories} kcal
                        </div>
                      </div>
                      <div style={{ fontSize: '24px' }}>{drink.emoji}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Analysis Results */}
            {drinkAnalysis && (
              <div className="feature-card fade-in" style={{ 
                background: drinkAnalysis.riskLevel === 'HIGH' || drinkAnalysis.riskLevel === 'EXTREME'
                  ? 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)'
                  : drinkAnalysis.riskLevel === 'MODERATE'
                  ? 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)'
                  : 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
                border: '2px solid',
                borderColor: drinkAnalysis.riskLevel === 'HIGH' || drinkAnalysis.riskLevel === 'EXTREME'
                  ? '#fca5a5'
                  : drinkAnalysis.riskLevel === 'MODERATE'
                  ? '#fcd34d'
                  : '#bbf7d0'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                  <div style={{ fontSize: '40px' }}>
                    {drinkAnalysis.riskLevel === 'LOW' ? '✅' : '⚠️'}
                  </div>
                  <div>
                    <div style={{ fontSize: '18px', fontWeight: 700, color: '#1f2937' }}>
                      Daily Sugar Analysis
                    </div>
                    <div style={{ fontSize: '13px', color: '#4b5563' }}>
                      Total: {drinkAnalysis.totalSugar}g sugar • {drinkAnalysis.totalCalories} kcal
                    </div>
                  </div>
                </div>

                <div className="health-metrics">
                  <div className={`metric-card ${
                    drinkAnalysis.riskLevel === 'HIGH' || drinkAnalysis.riskLevel === 'EXTREME' ? 'danger' :
                    drinkAnalysis.riskLevel === 'MODERATE' ? 'warning' : ''
                  }`}>
                    <div className="metric-value">{drinkAnalysis.percentOfDailyLimit}%</div>
                    <div className="metric-label">Of Daily Limit</div>
                  </div>
                  <div className={`metric-card ${
                    drinkAnalysis.riskLevel === 'HIGH' || drinkAnalysis.riskLevel === 'EXTREME' ? 'danger' :
                    drinkAnalysis.riskLevel === 'MODERATE' ? 'warning' : ''
                  }`}>
                    <div className="metric-value">{drinkAnalysis.riskLevel}</div>
                    <div className="metric-label">Health Risk</div>
                  </div>
                </div>

                {/* Recommendations */}
                {drinkAnalysis.recommendations.length > 0 && (
                  <div style={{ 
                    marginTop: '16px', 
                    padding: '14px', 
                    background: 'white', 
                    borderRadius: '12px',
                    borderLeft: '4px solid #6366f1'
                  }}>
                    <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937', marginBottom: '8px' }}>
                      💡 Recommendations
                    </div>
                    <div style={{ fontSize: '12px', color: '#4b5563', lineHeight: 1.6 }}>
                      {drinkAnalysis.recommendations.map((rec: string, idx: number) => (
                        <div key={idx} style={{ marginBottom: '6px' }}>• {rec}</div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Alternatives */}
                {drinkAnalysis.alternatives.length > 0 && (
                  <div style={{ marginTop: '16px', padding: '14px', background: 'white', borderRadius: '12px' }}>
                    <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937', marginBottom: '12px' }}>
                      ✨ Healthier Alternatives
                    </div>
                    {drinkAnalysis.alternatives.map((alt: any, idx: number) => (
                      <div key={idx} style={{ 
                        padding: '10px', 
                        background: 'linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%)',
                        borderRadius: '8px',
                        marginBottom: '8px',
                        border: '2px solid #6ee7b7'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <div>
                            <div style={{ fontWeight: 600, color: '#065f46', fontSize: '13px' }}>
                              {alt.drink.emoji} {alt.drink.name}
                            </div>
                            <div style={{ fontSize: '11px', color: '#047857', marginTop: '4px' }}>
                              Save {alt.sugarSaved}g sugar ({alt.percentReduction}% reduction)
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Weight Impact */}
                {drinkAnalysis.weightImpact && (
                  <div style={{ marginTop: '16px', padding: '14px', background: 'white', borderRadius: '12px' }}>
                    <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937', marginBottom: '12px' }}>
                      ⚖️ Weight Impact
                    </div>
                    <div style={{ fontSize: '12px', color: '#4b5563', lineHeight: 1.6 }}>
                      <div style={{ marginBottom: '8px' }}>
                        <strong>Current drinks:</strong> +{drinkAnalysis.weightImpact.monthlyGainKg} kg/month 
                        ({drinkAnalysis.weightImpact.yearlyGainKg} kg/year)
                      </div>
                      {drinkAnalysis.weightImpact.monthlyLossWithAlternatives > 0 && (
                        <div style={{ color: '#047857', fontWeight: 600 }}>
                          <strong>With alternatives:</strong> -{drinkAnalysis.weightImpact.monthlyLossWithAlternatives} kg/month potential loss!
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="nav-bar">
            <div className="nav-item" onClick={() => setCurrentPage('home')}>
              <div className="nav-icon">🏠</div>
              <div className="nav-label">Home</div>
            </div>
            <div className="nav-item" onClick={() => setCurrentPage('chatbot')}>
              <div className="nav-icon">💬</div>
              <div className="nav-label">Chat</div>
            </div>
            <div className="nav-item active">
              <div className="nav-icon">🥤</div>
              <div className="nav-label">Drinks</div>
            </div>
            <div className="nav-item" onClick={() => setMenuOpen(true)}>
              <div className="nav-icon">☰</div>
              <div className="nav-label">Menu</div>
            </div>
          </div>
        </div>

        {/* Camera Page */}
        <div className={`page ${currentPage === 'camera' ? 'active' : ''}`}>
          <div className="header">
            <div>
              <div className="greeting">Quick Scan 📷</div>
              <div className="subtext">Photo food logging</div>
            </div>
            <button className="menu-btn" onClick={() => setMenuOpen(true)}>☰</button>
          </div>

          <div className="content-section">
            <div className="feature-card">
              <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                <div style={{ fontSize: '80px', marginBottom: '20px' }}>📸</div>
                <h3 style={{ fontSize: '20px', color: '#1f2937', marginBottom: '12px' }}>
                  Snap Your Meal
                </h3>
                <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '24px' }}>
                  Take a photo of your food to instantly log nutrition, detect sauces, and get health recommendations
                </p>
                <button className="btn-primary">Open Camera</button>
              </div>
            </div>
          </div>

          <div className="nav-bar">
            <div className="nav-item" onClick={() => setCurrentPage('home')}>
              <div className="nav-icon">🏠</div>
              <div className="nav-label">Home</div>
            </div>
            <div className="nav-item" onClick={() => setCurrentPage('chatbot')}>
              <div className="nav-icon">💬</div>
              <div className="nav-label">Chat</div>
            </div>
            <div className="nav-item active">
              <div className="nav-icon">📸</div>
              <div className="nav-label">Scan</div>
            </div>
            <div className="nav-item" onClick={() => setMenuOpen(true)}>
              <div className="nav-icon">☰</div>
              <div className="nav-label">Menu</div>
            </div>
          </div>
        </div>

        {/* Placeholder pages for other features */}
        {['flavor-match', 'nearby-healthy', 'family'].map(pageId => (
          <div key={pageId} className={`page ${currentPage === pageId ? 'active' : ''}`}>
            <div className="header">
              <div>
                <div className="greeting">
                  {pageId === 'flavor-match' ? '🎯 Flavor Match' :
                   pageId === 'nearby-healthy' ? '📍 Nearby Healthy' :
                   '👨‍👩‍👧 Family Health'}
                </div>
                <div className="subtext">Coming soon</div>
              </div>
              <button className="menu-btn" onClick={() => setMenuOpen(true)}>☰</button>
            </div>
            <div className="content-section">
              <div className="feature-card">
                <div style={{ textAlign: 'center', padding: '60px 20px' }}>
                  <div style={{ fontSize: '80px', marginBottom: '20px' }}>🚧</div>
                  <h3 style={{ fontSize: '20px', color: '#1f2937', marginBottom: '12px' }}>
                    Feature In Development
                  </h3>
                  <p style={{ fontSize: '14px', color: '#6b7280' }}>
                    This feature will be available soon!
                  </p>
                </div>
              </div>
            </div>
            <div className="nav-bar">
              <div className="nav-item" onClick={() => setCurrentPage('home')}>
                <div className="nav-icon">🏠</div>
                <div className="nav-label">Home</div>
              </div>
              <div className="nav-item" onClick={() => setCurrentPage('chatbot')}>
                <div className="nav-icon">💬</div>
                <div className="nav-label">Chat</div>
              </div>
              <div className="nav-item" onClick={() => setCurrentPage('camera')}>
                <div className="nav-icon">📸</div>
                <div className="nav-label">Scan</div>
              </div>
              <div className="nav-item" onClick={() => setMenuOpen(true)}>
                <div className="nav-icon">☰</div>
                <div className="nav-label">Menu</div>
              </div>
            </div>
          </div>
        ))}

        {/* Menu Overlay */}
        <div 
          className={`menu-overlay ${menuOpen ? 'active' : ''}`}
          onClick={() => setMenuOpen(false)}
        />

        {/* Menu Sidebar */}
        <div className={`menu-sidebar ${menuOpen ? 'active' : ''}`}>
          <button className="menu-close" onClick={() => setMenuOpen(false)}>×</button>
          
          <div className="menu-header">
            <div className="menu-profile">
              <div className="menu-avatar">😊</div>
              <div>
                <div style={{ fontSize: '18px', fontWeight: 700 }}>Sarah Abdullah</div>
                <div style={{ fontSize: '13px', opacity: 0.9 }}>Premium Member</div>
              </div>
            </div>
          </div>

          <div className="menu-items">
            <div className="menu-item" onClick={() => { setCurrentPage('profile'); setMenuOpen(false); }}>
              <div className="menu-item-icon">👤</div>
              <div className="menu-item-text">
                <div className="menu-item-title">Profile & Health Tracker</div>
                <div className="menu-item-desc">View stats & manage profile</div>
              </div>
            </div>

            <div className="menu-item" onClick={() => { setCurrentPage('chatbot'); setMenuOpen(false); }}>
              <div className="menu-item-icon" style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' }}>💬</div>
              <div className="menu-item-text">
                <div className="menu-item-title">AI Assistant</div>
                <div className="menu-item-desc">Ask nutrition questions</div>
              </div>
            </div>

            <div className="menu-item" onClick={() => { setCurrentPage('drink-tracker'); setMenuOpen(false); }}>
              <div className="menu-item-icon" style={{ background: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)' }}>🥤</div>
              <div className="menu-item-text">
                <div className="menu-item-title">Drink Tracker</div>
                <div className="menu-item-desc">Monitor sugar intake</div>
              </div>
            </div>

            <div className="menu-item" onClick={() => { setNewsPopupOpen(true); setMenuOpen(false); }}>
              <div className="menu-item-icon" style={{ background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)' }}>📰</div>
              <div className="menu-item-text">
                <div className="menu-item-title">Health News</div>
                <div className="menu-item-desc">MOH Malaysia updates</div>
              </div>
            </div>
          </div>
        </div>

        {/* Health News Popup */}
        <div className={`news-popup ${newsPopupOpen ? 'show' : ''}`}>
          <button className="news-popup-close" onClick={() => setNewsPopupOpen(false)}>×</button>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
            <div style={{ fontSize: '32px' }}>📰</div>
            <div>
              <div style={{ fontSize: '16px', fontWeight: 700, color: '#1f2937' }}>
                MOH Health Alert
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>2 hours ago</div>
            </div>
          </div>
          <h4 style={{ fontSize: '15px', fontWeight: 600, color: '#1f2937', marginBottom: '8px' }}>
            Rising Diabetes Cases in Malaysia
          </h4>
          <p style={{ fontSize: '13px', color: '#4b5563', lineHeight: 1.6, marginBottom: '12px' }}>
            MOH reports 18.3% of Malaysian adults now have diabetes. High sugar drinks contribute significantly to this crisis.
          </p>
          <button 
            onClick={() => { setNewsPopupOpen(false); setCurrentPage('health-news'); }}
            style={{ 
              width: '100%', 
              padding: '10px', 
              background: 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)', 
              color: 'white', 
              border: 'none', 
              borderRadius: '12px', 
              fontSize: '13px', 
              fontWeight: 600, 
              cursor: 'pointer' 
            }}
          >
            Read Full Article
          </button>
        </div>
      </div>

      <style jsx>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .phone-container {
          width: 390px;
          height: 844px;
          background: #000;
          border-radius: 50px;
          padding: 12px;
          box-shadow: 0 50px 100px rgba(0,0,0,0.5);
          position: relative;
          overflow: hidden;
          margin: 0 auto;
        }

        .notch {
          position: absolute;
          top: 0;
          left: 50%;
          transform: translateX(-50%);
          width: 150px;
          height: 30px;
          background: #000;
          border-radius: 0 0 20px 20px;
          z-index: 100;
        }

        .screen {
          width: 100%;
          height: 100%;
          background: #fff;
          border-radius: 40px;
          overflow: hidden;
          position: relative;
        }

        .page {
          position: absolute;
          width: 100%;
          height: 100%;
          top: 0;
          left: 0;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s ease;
          overflow-y: auto;
          background: linear-gradient(to bottom, #f8f9ff 0%, #fff 100%);
        }

        .page.active {
          opacity: 1;
          pointer-events: all;
        }

        .header {
          padding: 50px 24px 20px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          color: white;
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
        }

        .greeting {
          font-size: 28px;
          font-weight: 700;
          margin-bottom: 8px;
        }

        .subtext {
          opacity: 0.9;
          font-size: 15px;
        }

        .menu-btn {
          width: 44px;
          height: 44px;
          background: rgba(255,255,255,0.2);
          border: none;
          border-radius: 12px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          color: white;
          flex-shrink: 0;
        }

        .avatar-container {
          margin: 20px 24px;
          background: white;
          border-radius: 24px;
          padding: 20px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }

        .avatar-display {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 16px;
        }

        .avatar {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 48px;
          animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }

        .avatar-info h3 {
          font-size: 18px;
          color: #1f2937;
          margin-bottom: 4px;
        }

        .avatar-status {
          display: inline-block;
          padding: 4px 12px;
          background: #10b981;
          color: white;
          border-radius: 12px;
          font-size: 12px;
          font-weight: 600;
        }

        .streak-info {
          display: flex;
          gap: 12px;
        }

        .streak-card {
          flex: 1;
          padding: 12px;
          background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);
          border-radius: 16px;
          color: white;
          text-align: center;
        }

        .streak-number {
          font-size: 24px;
          font-weight: 700;
          margin-bottom: 4px;
        }

        .streak-label {
          font-size: 12px;
          opacity: 0.9;
        }

        .quick-actions {
          margin: 0 24px 20px;
        }

        .section-title {
          font-size: 20px;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 16px;
        }

        .action-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .action-card {
          background: white;
          border-radius: 20px;
          padding: 20px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.08);
          cursor: pointer;
          transition: transform 0.2s, box-shadow 0.2s;
          border: 2px solid transparent;
        }

        .action-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.12);
          border-color: #6366f1;
        }

        .action-icon {
          width: 48px;
          height: 48px;
          border-radius: 16px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          margin-bottom: 12px;
        }

        .action-title {
          font-size: 15px;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 4px;
        }

        .action-desc {
          font-size: 12px;
          color: #6b7280;
        }

        .camera-button {
          position: fixed;
          bottom: 100px;
          right: 30px;
          width: 64px;
          height: 64px;
          border-radius: 50%;
          background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          color: white;
          box-shadow: 0 8px 24px rgba(245, 158, 11, 0.4);
          cursor: pointer;
          z-index: 50;
          transition: transform 0.2s;
        }

        .camera-button:hover {
          transform: scale(1.1);
        }

        .nav-bar {
          position: absolute;
          bottom: 0;
          left: 0;
          right: 0;
          background: white;
          padding: 12px 24px 32px;
          display: flex;
          justify-content: space-around;
          box-shadow: 0 -4px 20px rgba(0,0,0,0.08);
        }

        .nav-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          cursor: pointer;
          padding: 8px 16px;
          border-radius: 12px;
          transition: background 0.2s;
        }

        .nav-item:hover {
          background: rgba(99, 102, 241, 0.1);
        }

        .nav-item.active {
          background: rgba(99, 102, 241, 0.15);
        }

        .nav-icon {
          font-size: 24px;
          color: #9ca3af;
        }

        .nav-item.active .nav-icon {
          color: #6366f1;
        }

        .nav-label {
          font-size: 11px;
          color: #9ca3af;
          font-weight: 500;
        }

        .nav-item.active .nav-label {
          color: #6366f1;
        }

        .menu-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0,0,0,0.5);
          z-index: 998;
          opacity: 0;
          pointer-events: none;
          transition: opacity 0.3s;
        }

        .menu-overlay.active {
          opacity: 1;
          pointer-events: all;
        }

        .menu-sidebar {
          position: fixed;
          top: 0;
          right: 0;
          width: 85%;
          max-width: 320px;
          height: 100%;
          background: white;
          z-index: 999;
          transform: translateX(100%);
          transition: transform 0.3s;
          box-shadow: -4px 0 20px rgba(0,0,0,0.2);
          overflow-y: auto;
        }

        .menu-sidebar.active {
          transform: translateX(0);
        }

        .menu-header {
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          padding: 50px 24px 24px;
          color: white;
        }

        .menu-profile {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 20px;
        }

        .menu-avatar {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: rgba(255,255,255,0.2);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 32px;
        }

        .menu-close {
          position: absolute;
          top: 50px;
          right: 24px;
          width: 36px;
          height: 36px;
          background: rgba(255,255,255,0.2);
          border: none;
          border-radius: 50%;
          color: white;
          font-size: 20px;
          cursor: pointer;
        }

        .menu-items {
          padding: 20px 0;
        }

        .menu-item {
          padding: 16px 24px;
          display: flex;
          align-items: center;
          gap: 16px;
          cursor: pointer;
          transition: background 0.2s;
          border-left: 4px solid transparent;
        }

        .menu-item:hover {
          background: #f9fafb;
        }

        .menu-item-icon {
          width: 40px;
          height: 40px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
          color: white;
        }

        .menu-item-text {
          flex: 1;
        }

        .menu-item-title {
          font-size: 15px;
          font-weight: 600;
          color: #1f2937;
          margin-bottom: 2px;
        }

        .menu-item-desc {
          font-size: 12px;
          color: #6b7280;
        }

        .content-section {
          padding: 0 24px 120px;
        }

        .feature-card {
          background: white;
          border-radius: 20px;
          padding: 20px;
          margin-bottom: 16px;
          box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .feature-header {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
        }

        .feature-icon {
          width: 40px;
          height: 40px;
          border-radius: 12px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 20px;
        }

        .feature-title {
          font-size: 17px;
          font-weight: 600;
          color: #1f2937;
        }

        .btn-primary {
          width: 100%;
          padding: 16px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          color: white;
          border: none;
          border-radius: 16px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: transform 0.2s;
        }

        .btn-primary:hover {
          transform: translateY(-2px);
        }

        .chat-container {
          height: calc(100% - 180px);
          overflow-y: auto;
          padding: 20px 24px;
        }

        .chat-message {
          margin-bottom: 16px;
          animation: fadeIn 0.3s;
        }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .chat-message.bot {
          display: flex;
          gap: 12px;
        }

        .chat-message.user {
          display: flex;
          justify-content: flex-end;
        }

        .chat-avatar {
          width: 36px;
          height: 36px;
          border-radius: 50%;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          flex-shrink: 0;
        }

        .chat-bubble {
          max-width: 70%;
          padding: 12px 16px;
          border-radius: 16px;
          font-size: 14px;
          line-height: 1.5;
        }

        .chat-bubble.bot {
          background: #f3f4f6;
          color: #1f2937;
          border-bottom-left-radius: 4px;
        }

        .chat-bubble.user {
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          color: white;
          border-bottom-right-radius: 4px;
        }

        .chat-input-container {
          position: absolute;
          bottom: 80px;
          left: 0;
          right: 0;
          padding: 16px 24px;
          background: white;
          border-top: 1px solid #e5e7eb;
        }

        .chat-input {
          width: 100%;
          padding: 12px 16px;
          border: 2px solid #e5e7eb;
          border-radius: 24px;
          font-size: 14px;
          outline: none;
          transition: border-color 0.2s;
        }

        .chat-input:focus {
          border-color: #6366f1;
        }

        .chat-send-btn {
          position: absolute;
          right: 32px;
          top: 50%;
          transform: translateY(-50%);
          width: 36px;
          height: 36px;
          background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
          border: none;
          border-radius: 50%;
          color: white;
          font-size: 16px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .quick-questions {
          display: flex;
          gap: 8px;
          overflow-x: auto;
          padding: 8px 0;
          margin-top: 12px;
        }

        .quick-question {
          padding: 8px 16px;
          background: rgba(99, 102, 241, 0.1);
          color: #6366f1;
          border-radius: 20px;
          font-size: 13px;
          white-space: nowrap;
          cursor: pointer;
          transition: all 0.2s;
        }

        .quick-question:hover {
          background: rgba(99, 102, 241, 0.2);
        }

        .drink-card {
          background: white;
          border-radius: 16px;
          padding: 14px;
          margin-bottom: 12px;
          border: 2px solid #e5e7eb;
          cursor: pointer;
          transition: all 0.2s;
        }

        .drink-card:hover {
          border-color: #6366f1;
          box-shadow: 0 4px 12px rgba(99, 102, 241, 0.1);
        }

        .drink-card.selected {
          border-color: #6366f1;
          background: #f0f9ff;
        }

        .health-metrics {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          margin-top: 16px;
        }

        .metric-card {
          background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
          border-radius: 16px;
          padding: 16px;
          border: 2px solid #bbf7d0;
        }

        .metric-card.warning {
          background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
          border-color: #fcd34d;
        }

        .metric-card.danger {
          background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
          border-color: #fca5a5;
        }

        .metric-value {
          font-size: 24px;
          font-weight: 700;
          color: #1f2937;
          margin-bottom: 4px;
        }

        .metric-label {
          font-size: 12px;
          color: #6b7280;
          font-weight: 500;
        }

        .news-popup {
          position: fixed;
          bottom: 100px;
          left: 50%;
          transform: translateX(-50%) translateY(100%);
          width: 90%;
          max-width: 350px;
          background: white;
          border-radius: 20px;
          padding: 20px;
          box-shadow: 0 10px 40px rgba(0,0,0,0.3);
          z-index: 900;
          transition: transform 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .news-popup.show {
          transform: translateX(-50%) translateY(0);
        }

        .news-popup-close {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 28px;
          height: 28px;
          background: #f3f4f6;
          border: none;
          border-radius: 50%;
          cursor: pointer;
          font-size: 16px;
        }

        .fade-in {
          animation: fadeIn 0.5s ease;
        }
      `}</style>
    </div>
  );
}
