import { NextRequest, NextResponse } from 'next/server';

/**
 * API Route: /api/chat
 * 
 * This endpoint processes chat messages and returns AI responses
 * 
 * In production, you would integrate with OpenAI API or similar.
 * For now, this uses rule-based responses with Malaysian food knowledge.
 * 
 * Method: POST
 * Body: { message: string }
 * Returns: { response: string }
 */

interface ChatContext {
  message: string;
  context?: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: ChatContext = await request.json();
    const { message } = body;

    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }

    // Generate AI response
    const response = generateAIResponse(message.toLowerCase());

    return NextResponse.json({
      success: true,
      response
    });

  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json(
      { error: 'Failed to process message' },
      { status: 500 }
    );
  }
}

/**
 * Generates AI responses based on Malaysian food knowledge
 * 
 * How this works:
 * 1. Analyze user message for keywords
 * 2. Match against knowledge base
 * 3. Return contextually relevant response
 * 
 * In production, replace with:
 * - OpenAI GPT-4 API with Malaysian food context
 * - Custom fine-tuned model on Malaysian nutrition data
 * - RAG (Retrieval Augmented Generation) with MyFCD database
 */
function generateAIResponse(message: string): string {
  // Dinner recommendations
  if (message.includes('dinner') || message.includes('makan malam')) {
    return `For a healthy Malaysian dinner, I recommend:<br><br>` +
           `🐟 <strong>Ikan Bakar (Grilled Fish)</strong> with ulam and sambal (use sparingly)<br>` +
           `Calories: ~300 kcal | Protein: 35g | Low carb<br><br>` +
           `🥗 <strong>Sayur Campur</strong> (mixed vegetables) with less oil<br>` +
           `Rich in fiber and vitamins | Only ~80 kcal<br><br>` +
           `🍜 <strong>Clear Soup</strong> instead of santan-based curries<br>` +
           `Reduces calories by 200-300 kcal per serving<br><br>` +
           `<em>Pro tip:</em> Avoid heavy sauces and fried foods after 7 PM. Would you like specific recipes?`;
  }

  // Nasi lemak analysis
  if (message.includes('nasi lemak')) {
    return `Nasi lemak can be healthier with smart choices! Here's how:<br><br>` +
           `<strong>Standard Nasi Lemak:</strong> 650-750 calories<br>` +
           `<strong>Healthier Version:</strong> 380-450 calories<br><br>` +
           `<strong>Modifications:</strong><br>` +
           `✓ Request <em>less coconut rice</em> (saves 150 kcal)<br>` +
           `✓ Choose <em>boiled/grilled egg</em> vs fried (-80 kcal)<br>` +
           `✓ Add <em>more cucumber & vegetables</em> (+fiber, +fullness)<br>` +
           `✓ Limit <em>sambal portion</em> to 1-2 tbsp (-100 kcal, -600mg sodium)<br>` +
           `✓ Skip <em>fried chicken/rendang</em>, choose ikan bilis instead<br><br>` +
           `This reduces total calories by 40% and sodium by 60%!`;
  }

  // Drinks and sugar
  if (message.includes('drink') || message.includes('sugar') || message.includes('minuman')) {
    return `Malaysian drinks have ALARMINGLY high sugar! Here's the truth:<br><br>` +
           `<strong>🚨 High Sugar Drinks:</strong><br>` +
           `• Teh Tarik: 28g sugar (5.6 teaspoons!)<br>` +
           `• Teh Ais: 35g sugar (7 teaspoons!)<br>` +
           `• Milo Ais: 38g sugar (7.6 teaspoons!)<br>` +
           `• Sirap Bandung: 45g sugar (9 teaspoons!)<br><br>` +
           `<strong>✅ Healthier Alternatives:</strong><br>` +
           `• Teh O Kosong: 0g sugar (save 28g!)<br>` +
           `• Kopi O Kosong: 0g sugar<br>` +
           `• Teh O Ais Limau: 5g sugar (save 30g!)<br>` +
           `• Plain water with lemon: 0g sugar<br><br>` +
           `<strong>Impact:</strong> Switching saves 840g sugar/month = <em>1.5 kg weight loss!</em><br><br>` +
           `Check our Drink Tracker for detailed analysis! 🥤`;
  }

  // Weight loss
  if (message.includes('weight loss') || message.includes('lose weight') || message.includes('kurus')) {
    return `Evidence-based weight loss for Malaysians:<br><br>` +
           `<strong>1️⃣ Follow Suku-Suku Separuh Method:</strong><br>` +
           `Quarter plate: Rice/carbs<br>` +
           `Quarter plate: Protein<br>` +
           `Half plate: Vegetables<br><br>` +
           `<strong>2️⃣ Cut Sugary Drinks:</strong><br>` +
           `Saves 300-500 kcal/day = 2-3 kg/month!<br><br>` +
           `<strong>3️⃣ Choose Ulam & Salad:</strong><br>` +
           `High fiber keeps you full, low calories<br><br>` +
           `<strong>4️⃣ Walk 10,000 Steps Daily:</strong><br>` +
           `Burns 300-400 kcal + improves metabolism<br><br>` +
           `<strong>5️⃣ Avoid Mamak Supper:</strong><br>` +
           `Late night eating = poor sleep + weight gain<br><br>` +
           `<strong>Realistic Goal:</strong> 2-4 kg per month (safe & sustainable)<br><br>` +
           `Would you like a personalized meal plan?`;
  }

  // Roti canai
  if (message.includes('roti canai') || message.includes('roti')) {
    return `Roti canai is delicious but calorie-dense:<br><br>` +
           `<strong>1 piece Roti Canai:</strong> 300 calories, 12g fat<br>` +
           `<strong>With dhal curry:</strong> +60 calories<br>` +
           `<strong>With sugar (roti kosong):</strong> +100 calories<br><br>` +
           `<strong>Healthier approach:</strong><br>` +
           `✓ Limit to 1 piece max<br>` +
           `✓ Choose dhal over sugar<br>` +
           `✓ Skip the condensed milk dip<br>` +
           `✓ Pair with plain tea (kosong)<br>` +
           `✓ Add side of fresh fruit<br><br>` +
           `<strong>Better alternatives:</strong><br>` +
           `• Thosai (dosa): 150 calories (50% less!)<br>` +
           `• Chapati: 120 calories<br>` +
           `• Idli: 80 calories per piece<br><br>` +
           `Enjoy Malaysian food mindfully! 🥞`;
  }

  // Char kuey teow
  if (message.includes('char kuey teow') || message.includes('ckt')) {
    return `Char Kuey Teow is high in calories and sodium:<br><br>` +
           `<strong>Standard plate:</strong> 680 calories, 1200mg sodium<br>` +
           `That's 60% of your daily sodium limit!<br><br>` +
           `<strong>Health concerns:</strong><br>` +
           `• High in saturated fat (from lard/oil)<br>` +
           `• Very high sodium (raises blood pressure)<br>` +
           `• Low in vegetables and fiber<br>` +
           `• Can spike blood sugar rapidly<br><br>` +
           `<strong>Occasional treat tips:</strong><br>` +
           `✓ Request less oil ("kurang minyak")<br>` +
           `✓ Ask for extra bean sprouts<br>` +
           `✓ Share one plate with a friend<br>` +
           `✓ Pair with Chinese tea (no sugar)<br>` +
           `✓ Limit to once per week max<br><br>` +
           `Consider healthier noodles like bee hoon soup or koay teow soup instead!`;
  }

  // Mamak food
  if (message.includes('mamak') || message.includes('teh tarik')) {
    return `Mamak food is flavorful but often unhealthy:<br><br>` +
           `<strong>Common Issues:</strong><br>` +
           `• Very high sodium (causes hypertension)<br>` +
           `• Excessive oil and ghee<br>` +
           `• Large portions of refined carbs<br>` +
           `• Sugary drinks (teh tarik has 28g sugar!)<br><br>` +
           `<strong>Healthier Mamak Choices:</strong><br>` +
           `✅ Tandoori chicken (grilled, not fried)<br>` +
           `✅ Vegetable briyani (small portion)<br>` +
           `✅ Chapati instead of roti canai<br>` +
           `✅ Dhal for protein and fiber<br>` +
           `✅ Plain water or teh o kosong<br><br>` +
           `<strong>Things to avoid:</strong><br>` +
           `❌ Murtabak (500-700 kcal!)<br>` +
           `❌ Roti boom (extremely oily)<br>` +
           `❌ Maggi goreng (instant noodles + oil)<br>` +
           `❌ Sweet lassi (high sugar)<br><br>` +
           `Enjoy mamak culture, but choose wisely!`;
  }

  // Diabetes
  if (message.includes('diabetes') || message.includes('kencing manis')) {
    return `Diabetes is a serious concern in Malaysia:<br><br>` +
           `<strong>🚨 Malaysia Statistics (2023):</strong><br>` +
           `• 18.3% of adults have diabetes<br>` +
           `• 3.9 million Malaysians affected<br>` +
           `• 1 in 5 adults over 30 have diabetes<br>` +
           `• Many don't know they have it!<br><br>` +
           `<strong>Main Risk Factors:</strong><br>` +
           `1. Sugary drinks (major contributor!)<br>` +
           `2. Excessive white rice consumption<br>` +
           `3. Lack of physical activity<br>` +
           `4. Family history<br>` +
           `5. Obesity<br><br>` +
           `<strong>Prevention Steps:</strong><br>` +
           `✓ Cut ALL sugary drinks immediately<br>` +
           `✓ Replace white rice with brown rice<br>` +
           `✓ Exercise 150 min/week minimum<br>` +
           `✓ Get HbA1c test annually<br>` +
           `✓ Maintain healthy BMI (below 25)<br><br>` +
           `<strong>Warning Signs:</strong><br>` +
           `• Excessive thirst<br>` +
           `• Frequent urination<br>` +
           `• Unexplained weight loss<br>` +
           `• Fatigue<br>` +
           `• Slow-healing wounds<br><br>` +
           `If you have these symptoms, see a doctor immediately!`;
  }

  // General food query
  if (message.includes('healthy') || message.includes('sihat')) {
    return `Malaysian healthy eating principles:<br><br>` +
           `<strong>✅ DO:</strong><br>` +
           `• Eat more ulam (raw vegetables)<br>` +
           `• Choose steamed/grilled over fried<br>` +
           `• Use herbs and spices for flavor<br>` +
           `• Eat brown rice instead of white<br>` +
           `• Drink plain water (2-3 liters daily)<br>` +
           `• Follow Suku-Suku Separuh method<br><br>` +
           `<strong>❌ AVOID:</strong><br>` +
           `• Sugary drinks (biggest enemy!)<br>` +
           `• Excessive sambal and sauces<br>` +
           `• Fried foods daily<br>` +
           `• Large portions of rice<br>` +
           `• Santan-based curries regularly<br>` +
           `• Late night mamak sessions<br><br>` +
           `Remember: You can enjoy Malaysian food while staying healthy!<br>` +
           `It's about smart choices, not restriction. 🇲🇾`;
  }

  // Default response
  return `I'm here to help with Malaysian nutrition! I can advise on:<br><br>` +
         `🍽️ <strong>Meal Planning:</strong> Nasi lemak, roti canai, char kuey teow, etc.<br>` +
         `🥤 <strong>Drink Analysis:</strong> Sugar content in teh tarik, milo, etc.<br>` +
         `⚖️ <strong>Weight Management:</strong> Evidence-based tips for Malaysians<br>` +
         `🏥 <strong>Health Conditions:</strong> Diabetes, hypertension diet advice<br>` +
         `🥘 <strong>Malaysian Food:</strong> Nutrition info on local favorites<br>` +
         `💪 <strong>Healthy Choices:</strong> Better alternatives at mamak, hawker centers<br><br>` +
         `What would you like to know? Just ask in English or Bahasa Malaysia!`;
}
