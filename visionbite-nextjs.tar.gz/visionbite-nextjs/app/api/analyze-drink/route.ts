import { NextRequest, NextResponse } from 'next/server';
import { analyzeDrinkConsumption } from '@/lib/dataAnalysis';

/**
 * API Route: /api/analyze-drink
 * 
 * This endpoint analyzes drink consumption and returns health data
 * 
 * Method: POST
 * Body: {
 *   breakfast?: string (drink ID),
 *   lunch?: string (drink ID),
 *   dinner?: string (drink ID)
 * }
 * 
 * Returns: DrinkAnalysis object with:
 * - Total sugar and calories
 * - Health risk level
 * - Personalized recommendations
 * - Healthy alternatives
 * - Weight impact projections
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { breakfast, lunch, dinner } = body;

    // Validate input
    if (!breakfast && !lunch && !dinner) {
      return NextResponse.json(
        { error: 'At least one meal drink must be provided' },
        { status: 400 }
      );
    }

    // Perform analysis
    const analysis = analyzeDrinkConsumption({
      breakfast,
      lunch,
      dinner
    });

    // Return results
    return NextResponse.json({
      success: true,
      data: analysis
    });

  } catch (error) {
    console.error('Error analyzing drinks:', error);
    return NextResponse.json(
      { error: 'Failed to analyze drinks' },
      { status: 500 }
    );
  }
}

/**
 * GET method - returns available drinks
 */
export async function GET() {
  const { malaysianDrinks } = await import('@/data/malaysianFoodData');
  
  return NextResponse.json({
    success: true,
    drinks: malaysianDrinks
  });
}
