// Malaysian Food Composition Database (MyFCD)
// Source: Ministry of Health Malaysia

export interface DrinkData {
  id: string;
  name: string;
  category: string;
  sugarGrams: number;
  calories: number;
  servingSize: string;
  emoji: string;
  ingredients: string[];
  healthRisks: string[];
}

export interface FoodData {
  id: string;
  name: string;
  category: string;
  cuisine: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sodium: number;
  servingSize: string;
}

export const malaysianDrinks: DrinkData[] = [
  {
    id: 'teh-tarik',
    name: 'Teh Tarik',
    category: 'Hot Beverage',
    sugarGrams: 28,
    calories: 140,
    servingSize: '1 cup (250ml)',
    emoji: '☕',
    ingredients: ['Black tea', 'Condensed milk', 'Evaporated milk', 'Sugar'],
    healthRisks: ['High sugar', 'High calories', 'Contributes to diabetes risk']
  },
  {
    id: 'kopi-o',
    name: 'Kopi O',
    category: 'Hot Beverage',
    sugarGrams: 12,
    calories: 60,
    servingSize: '1 cup (250ml)',
    emoji: '☕',
    ingredients: ['Black coffee', 'Sugar'],
    healthRisks: ['Moderate sugar', 'Can increase heart rate']
  },
  {
    id: 'teh-ais',
    name: 'Teh Ais (Iced Tea)',
    category: 'Cold Beverage',
    sugarGrams: 35,
    calories: 175,
    servingSize: '1 glass (350ml)',
    emoji: '🧊',
    ingredients: ['Black tea', 'Condensed milk', 'Evaporated milk', 'Sugar', 'Ice'],
    healthRisks: ['Very high sugar', 'High calories', 'Major diabetes risk factor']
  },
  {
    id: 'sirap-bandung',
    name: 'Sirap Bandung',
    category: 'Cold Beverage',
    sugarGrams: 45,
    calories: 225,
    servingSize: '1 glass (350ml)',
    emoji: '🥤',
    ingredients: ['Rose syrup', 'Condensed milk', 'Evaporated milk', 'Ice'],
    healthRisks: ['Extremely high sugar', 'Very high calories', 'Severe diabetes risk']
  },
  {
    id: 'milo-ais',
    name: 'Milo Ais',
    category: 'Cold Beverage',
    sugarGrams: 38,
    calories: 190,
    servingSize: '1 glass (350ml)',
    emoji: '🥛',
    ingredients: ['Milo powder', 'Condensed milk', 'Evaporated milk', 'Ice'],
    healthRisks: ['Very high sugar', 'High calories', 'Can spike blood glucose']
  },
  {
    id: 'plain-water',
    name: 'Plain Water',
    category: 'Water',
    sugarGrams: 0,
    calories: 0,
    servingSize: '1 glass (350ml)',
    emoji: '💧',
    ingredients: ['Water'],
    healthRisks: []
  },
  {
    id: 'teh-o-kosong',
    name: 'Teh O Kosong',
    category: 'Hot Beverage',
    sugarGrams: 0,
    calories: 5,
    servingSize: '1 cup (250ml)',
    emoji: '☕',
    ingredients: ['Black tea'],
    healthRisks: []
  },
  {
    id: 'kopi-o-kosong',
    name: 'Kopi O Kosong',
    category: 'Hot Beverage',
    sugarGrams: 0,
    calories: 5,
    servingSize: '1 cup (250ml)',
    emoji: '☕',
    ingredients: ['Black coffee'],
    healthRisks: []
  },
  {
    id: 'teh-o-ais-limau',
    name: 'Teh O Ais Limau',
    category: 'Cold Beverage',
    sugarGrams: 5,
    calories: 25,
    servingSize: '1 glass (350ml)',
    emoji: '🍋',
    ingredients: ['Black tea', 'Lime juice', 'Minimal sugar', 'Ice'],
    healthRisks: []
  },
  {
    id: 'air-kosong',
    name: 'Air Kosong (Plain Water)',
    category: 'Water',
    sugarGrams: 0,
    calories: 0,
    servingSize: '1 glass (350ml)',
    emoji: '💧',
    ingredients: ['Water'],
    healthRisks: []
  }
];

export const malaysianFood: FoodData[] = [
  {
    id: 'nasi-lemak',
    name: 'Nasi Lemak',
    category: 'Main Dish',
    cuisine: 'Malay',
    calories: 520,
    protein: 15,
    carbs: 65,
    fat: 22,
    fiber: 3,
    sodium: 850,
    servingSize: '1 plate (400g)'
  },
  {
    id: 'char-kuey-teow',
    name: 'Char Kuey Teow',
    category: 'Main Dish',
    cuisine: 'Chinese',
    calories: 680,
    protein: 18,
    carbs: 70,
    fat: 32,
    fiber: 4,
    sodium: 1200,
    servingSize: '1 plate (350g)'
  },
  {
    id: 'roti-canai',
    name: 'Roti Canai',
    category: 'Bread',
    cuisine: 'Mamak',
    calories: 300,
    protein: 6,
    carbs: 42,
    fat: 12,
    fiber: 2,
    sodium: 420,
    servingSize: '1 piece (150g)'
  },
  {
    id: 'nasi-kandar',
    name: 'Nasi Kandar',
    category: 'Main Dish',
    cuisine: 'Mamak',
    calories: 750,
    protein: 25,
    carbs: 85,
    fat: 30,
    fiber: 5,
    sodium: 1500,
    servingSize: '1 plate (450g)'
  }
];

// WHO Daily Recommendations
export const dailyRecommendations = {
  sugar: 50, // grams (WHO recommendation for 2000 kcal diet)
  calories: 2000,
  sodium: 2000, // mg
  protein: 50, // g
  carbs: 275, // g
  fat: 70, // g
  fiber: 25 // g
};

// Health risk thresholds
export const healthThresholds = {
  sugar: {
    low: 25, // < 50% of daily limit
    moderate: 35, // 50-70% of daily limit
    high: 50, // > 70% of daily limit
    extreme: 70 // > 140% of daily limit
  },
  bmi: {
    underweight: 18.5,
    normal: 25,
    overweight: 30,
    obese: 35
  }
};
