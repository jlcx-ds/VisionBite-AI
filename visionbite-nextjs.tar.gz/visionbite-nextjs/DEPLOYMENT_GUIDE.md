# 🚀 VisionBite AI - Deployment Guide

## Quick Start (5 minutes)

### Option 1: Vercel CLI (Recommended)

```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Navigate to project
cd visionbite-nextjs

# 3. Deploy!
vercel

# Follow prompts:
# - Set up and deploy? Yes
# - Which scope? [Your account]
# - Link to existing project? No
# - Project name? visionbite-ai
# - Directory? ./
# - Override settings? No

# ✅ Done! Your app is live
```

### Option 2: Vercel Dashboard

1. **Create Vercel Account**
   - Go to https://vercel.com/signup
   - Sign up with GitHub/GitLab/Bitbucket

2. **Import Project**
   - Click "Add New" → "Project"
   - Choose "Import Git Repository" OR "Upload"

3. **Configure**
   - Framework: Next.js (auto-detected)
   - Root Directory: ./
   - Build Command: `npm run build`
   - Output Directory: .next

4. **Deploy**
   - Click "Deploy"
   - Wait ~30 seconds
   - ✅ Live!

## Environment Setup

No environment variables needed! Everything works out of the box.

## Vercel Configuration

Create `vercel.json` (optional, for advanced config):

```json
{
  "buildCommand": "npm run build",
  "devCommand": "npm run dev",
  "installCommand": "npm install",
  "framework": "nextjs",
  "outputDirectory": ".next"
}
```

## Post-Deployment

### 1. Custom Domain

```bash
# Add custom domain
vercel domains add yourdomain.com

# Or via dashboard:
# Project Settings → Domains → Add
```

### 2. Check Deployment

```bash
# View deployment logs
vercel logs

# Check status
vercel inspect
```

### 3. Test Features

- ✅ Homepage loads
- ✅ Chatbot responds
- ✅ Drink tracker analyzes
- ✅ All API routes work
- ✅ Mobile responsive

## Troubleshooting

### Build Fails

```bash
# Test locally first
npm run build

# Check errors in terminal
# Fix TypeScript/ESLint issues
```

### API Routes Not Working

- Verify files in `app/api/` folder
- Check imports use `@/` prefix
- Ensure TypeScript compiles

### Slow Loading

- Vercel automatically optimizes
- Images lazy-loaded
- Code-split by page
- Cached globally via CDN

## Performance

Expected metrics:
- ⚡ First Load: < 1s
- 📊 Lighthouse Score: 90+
- 🌍 Global CDN: Yes
- 🔄 Auto-scaling: Yes

## Cost

**Vercel Free Tier includes:**
- ✅ Unlimited deployments
- ✅ 100 GB bandwidth/month
- ✅ Serverless functions
- ✅ Automatic HTTPS
- ✅ Global CDN

**Upgrade needed when:**
- > 100 GB bandwidth/month
- > 100 serverless function executions/hour
- Need team collaboration

## Monitoring

```bash
# View analytics
vercel analytics

# Check performance
vercel insights
```

## Updates

```bash
# Make changes to code
# Then redeploy:
vercel --prod

# Or push to Git (if connected)
git push origin main
# Auto-deploys!
```

## Support

- Vercel Docs: https://vercel.com/docs
- Next.js Docs: https://nextjs.org/docs
- Support: https://vercel.com/support

---

**Your VisionBite AI is now live! 🎉**

Share the URL with users and start helping Malaysians eat healthier!
