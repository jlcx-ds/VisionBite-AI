// Data Analysis Utilities for VisionBite AI
// This file contains all the logic for analyzing food and drink data

import { 
  DrinkData, 
  malaysianDrinks, 
  dailyRecommendations, 
  healthThresholds 
} from '@/data/malaysianFoodData';

export interface DrinkAnalysis {
  totalSugar: number;
  totalCalories: number;
  percentOfDailyLimit: number;
  riskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME';
  healthRisks: string[];
  recommendations: string[];
  alternatives: DrinkAlternative[];
  weightImpact: WeightImpact;
}

export interface DrinkAlternative {
  drink: DrinkData;
  sugarSaved: number;
  caloriesSaved: number;
  percentReduction: number;
}

export interface WeightImpact {
  monthlyGainKg: number;
  yearlyGainKg: number;
  monthlyLossWithAlternatives: number;
}

/**
 * Analyzes drink consumption and returns comprehensive health data
 * 
 * How it works:
 * 1. Calculate total sugar and calories from selected drinks
 * 2. Compare against WHO daily recommendations (50g sugar)
 * 3. Determine risk level based on thresholds
 * 4. Find healthier alternatives with similar taste profiles
 * 5. Calculate weight impact projections
 */
export function analyzeDrinkConsumption(
  selectedDrinks: { breakfast?: string; lunch?: string; dinner?: string }
): DrinkAnalysis {
  // Step 1: Get drink objects from IDs
  const drinks: DrinkData[] = [];
  if (selectedDrinks.breakfast) {
    const drink = malaysianDrinks.find(d => d.id === selectedDrinks.breakfast);
    if (drink) drinks.push(drink);
  }
  if (selectedDrinks.lunch) {
    const drink = malaysianDrinks.find(d => d.id === selectedDrinks.lunch);
    if (drink) drinks.push(drink);
  }
  if (selectedDrinks.dinner) {
    const drink = malaysianDrinks.find(d => d.id === selectedDrinks.dinner);
    if (drink) drinks.push(drink);
  }

  // Step 2: Calculate totals
  const totalSugar = drinks.reduce((sum, drink) => sum + drink.sugarGrams, 0);
  const totalCalories = drinks.reduce((sum, drink) => sum + drink.calories, 0);
  const percentOfDailyLimit = (totalSugar / dailyRecommendations.sugar) * 100;

  // Step 3: Determine risk level
  const riskLevel = calculateRiskLevel(totalSugar);

  // Step 4: Collect all health risks
  const healthRisks = drinks.flatMap(drink => drink.healthRisks);

  // Step 5: Generate recommendations
  const recommendations = generateRecommendations(totalSugar, riskLevel);

  // Step 6: Find alternatives
  const alternatives = findAlternatives(drinks);

  // Step 7: Calculate weight impact
  const weightImpact = calculateWeightImpact(totalCalories, alternatives);

  return {
    totalSugar,
    totalCalories,
    percentOfDailyLimit: Math.round(percentOfDailyLimit),
    riskLevel,
    healthRisks: Array.from(new Set(healthRisks)), // Remove duplicates
    recommendations,
    alternatives,
    weightImpact
  };
}

/**
 * Calculates risk level based on sugar consumption
 * Uses WHO thresholds for sugar intake
 */
function calculateRiskLevel(totalSugar: number): 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME' {
  if (totalSugar < healthThresholds.sugar.low) return 'LOW';
  if (totalSugar < healthThresholds.sugar.moderate) return 'MODERATE';
  if (totalSugar < healthThresholds.sugar.extreme) return 'HIGH';
  return 'EXTREME';
}

/**
 * Generates personalized recommendations based on sugar intake
 */
function generateRecommendations(
  totalSugar: number, 
  riskLevel: string
): string[] {
  const recommendations: string[] = [];

  if (riskLevel === 'LOW') {
    recommendations.push('Great! Your sugar intake is within healthy limits.');
    recommendations.push('Continue choosing low-sugar beverages.');
    recommendations.push('Stay hydrated with water throughout the day.');
  } else if (riskLevel === 'MODERATE') {
    recommendations.push('You\'re approaching the daily sugar limit.');
    recommendations.push('Consider switching to Teh O Kosong or plain water.');
    recommendations.push('Reduce sugar gradually to avoid sudden cravings.');
  } else if (riskLevel === 'HIGH') {
    recommendations.push('⚠️ HIGH RISK: You\'ve exceeded the WHO daily sugar limit!');
    recommendations.push('Switch to sugar-free alternatives immediately.');
    recommendations.push('Drink extra water to help flush out excess sugar.');
    recommendations.push('Consider scheduling a diabetes screening.');
  } else { // EXTREME
    recommendations.push('🚨 CRITICAL: Extremely high sugar intake detected!');
    recommendations.push('Immediate action required to reduce diabetes risk.');
    recommendations.push('Eliminate all sugary drinks for the rest of the day.');
    recommendations.push('Consult a healthcare provider about your sugar intake.');
    recommendations.push('Risk of blood sugar spike and insulin resistance.');
  }

  return recommendations;
}

/**
 * Finds healthier alternatives with the same flavor profile
 * Algorithm:
 * 1. Identify high-sugar drinks (>20g)
 * 2. Find low-sugar alternatives in same category
 * 3. Calculate savings
 * 4. Sort by most effective (highest savings)
 */
function findAlternatives(selectedDrinks: DrinkData[]): DrinkAlternative[] {
  const alternatives: DrinkAlternative[] = [];

  // Only suggest alternatives for high-sugar drinks
  const highSugarDrinks = selectedDrinks.filter(d => d.sugarGrams > 20);

  for (const drink of highSugarDrinks) {
    // Find similar but healthier drinks
    let alternativeDrink: DrinkData | undefined;

    // Logic for finding alternatives:
    if (drink.name.includes('Teh')) {
      alternativeDrink = malaysianDrinks.find(d => d.id === 'teh-o-kosong');
    } else if (drink.name.includes('Kopi')) {
      alternativeDrink = malaysianDrinks.find(d => d.id === 'kopi-o-kosong');
    } else if (drink.name.includes('Milo')) {
      alternativeDrink = malaysianDrinks.find(d => d.id === 'teh-o-ais-limau');
    } else if (drink.name.includes('Sirap')) {
      alternativeDrink = malaysianDrinks.find(d => d.id === 'plain-water');
    } else {
      alternativeDrink = malaysianDrinks.find(d => d.id === 'plain-water');
    }

    if (alternativeDrink) {
      const sugarSaved = drink.sugarGrams - alternativeDrink.sugarGrams;
      const caloriesSaved = drink.calories - alternativeDrink.calories;
      const percentReduction = Math.round((sugarSaved / drink.sugarGrams) * 100);

      alternatives.push({
        drink: alternativeDrink,
        sugarSaved,
        caloriesSaved,
        percentReduction
      });
    }
  }

  // Sort by most effective (highest sugar reduction)
  return alternatives.sort((a, b) => b.sugarSaved - a.sugarSaved);
}

/**
 * Calculates weight impact projections
 * Formula: 3,500 calories = 1 pound (0.45 kg) = 7,700 calories = 1 kg
 * 
 * This uses established nutritional science:
 * - Excess calories are stored as fat
 * - 7,700 kcal excess = 1 kg weight gain
 * - Daily excess compounds over time
 */
function calculateWeightImpact(
  dailyCalories: number,
  alternatives: DrinkAlternative[]
): WeightImpact {
  // Calculate monthly weight gain from current drinks
  const monthlyExcessCalories = dailyCalories * 30;
  const monthlyGainKg = Number((monthlyExcessCalories / 7700).toFixed(2));
  const yearlyGainKg = Number((monthlyGainKg * 12).toFixed(1));

  // Calculate potential savings with alternatives
  const totalCaloriesSaved = alternatives.reduce(
    (sum, alt) => sum + alt.caloriesSaved, 
    0
  );
  const monthlyCaloriesSaved = totalCaloriesSaved * 30;
  const monthlyLossWithAlternatives = Number(
    (monthlyCaloriesSaved / 7700).toFixed(2)
  );

  return {
    monthlyGainKg,
    yearlyGainKg,
    monthlyLossWithAlternatives
  };
}

/**
 * Analyzes a single drink and returns detailed nutrition info
 */
export function analyzeSingleDrink(drinkId: string): DrinkData | null {
  return malaysianDrinks.find(d => d.id === drinkId) || null;
}

/**
 * Gets all available drinks by category
 */
export function getDrinksByCategory(category: string): DrinkData[] {
  return malaysianDrinks.filter(d => d.category === category);
}

/**
 * Searches drinks by name
 */
export function searchDrinks(query: string): DrinkData[] {
  const lowerQuery = query.toLowerCase();
  return malaysianDrinks.filter(d => 
    d.name.toLowerCase().includes(lowerQuery) ||
    d.category.toLowerCase().includes(lowerQuery)
  );
}

/**
 * Gets all healthy drink alternatives (sugar < 10g)
 */
export function getHealthyDrinks(): DrinkData[] {
  return malaysianDrinks.filter(d => d.sugarGrams < 10);
}

/**
 * Calculate BMI and health status
 */
export function calculateBMI(weightKg: number, heightCm: number) {
  const heightM = heightCm / 100;
  const bmi = weightKg / (heightM * heightM);
  
  let status: string;
  if (bmi < healthThresholds.bmi.underweight) status = 'Underweight';
  else if (bmi < healthThresholds.bmi.normal) status = 'Normal';
  else if (bmi < healthThresholds.bmi.overweight) status = 'Overweight';
  else if (bmi < healthThresholds.bmi.obese) status = 'Obese';
  else status = 'Severely Obese';

  return {
    bmi: Number(bmi.toFixed(1)),
    status,
    recommendation: getBMIRecommendation(status)
  };
}

function getBMIRecommendation(status: string): string {
  switch (status) {
    case 'Underweight':
      return 'Consider increasing calorie intake with nutrient-dense foods.';
    case 'Normal':
      return 'Maintain your current healthy lifestyle!';
    case 'Overweight':
      return 'Reduce sugary drinks and increase physical activity.';
    case 'Obese':
      return 'Consult a healthcare provider for a weight management plan.';
    case 'Severely Obese':
      return 'Immediate medical consultation recommended for health risks.';
    default:
      return '';
  }
}
